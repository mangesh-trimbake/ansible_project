ansible-playbook -i inventory deploy.yml --ssh-common-args="-F ssh_config"
